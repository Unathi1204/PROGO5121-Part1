/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationloginchat;

/**
 *
 * @author RC_Student_Lab
 * Login class that handles user registration and authentication
 * Created with assistance from ChatGPT (OpenAI, 2024)
 */
        import java.util.Scanner;
import java.util.regex.Pattern;

public class RegistrationLoginChat {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Registration
        System.out.println("=== User Registration ===");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter South African cell phone number (with +27): ");
        String cellPhone = scanner.nextLine();

        // Create login object
        Login login = new Login(firstName, lastName, username, password, cellPhone);

        // Register user
        System.out.println(login.registerUser());

        // Login
        System.out.println("\n=== User Login ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        if (login.loginUser(loginUsername, loginPassword)) {
            System.out.println(login.returnLoginStatus(true));
            startChat(scanner, login);
        } else {
            System.out.println(login.returnLoginStatus(false));
        }
    }

    // Simple chat inside the same program
    private static void startChat(Scanner scanner, Login login) {
        System.out.println("\n=== Chat System ===");
        System.out.println("Type 'exit' to leave chat.");

        while (true) {
            System.out.print(login.getFirstName() + ": ");
            String message = scanner.nextLine();

            if (message.equalsIgnoreCase("exit")) {
                System.out.println("Chat ended.");
                break;
            }

            // Simulated message statuses
            System.out.println("[Sent] " + message);
            System.out.println("[Received] " + message);
            System.out.println("[Read] " + message);
        }
    }
}

// ==========================
// LOGIN CLASS
// ==========================
class Login {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhone;

    public Login(String firstName, String lastName, String username, String password, String cellPhone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
    }

    public String getFirstName() {
        return firstName;
    }

    // Username check
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // Password complexity check
    public boolean checkPasswordComplexity() {
        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        return password.length() >= 8 && hasUppercase && hasDigit && hasSpecialChar;
    }

    // Cell phone format check
    public boolean checkCellPhoneNumber() {
        String regex = "^\\+27\\d{9}$";  // +27 followed by 9 digits
        return Pattern.matches(regex, cellPhone);
    }

    // Register user
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User registered successfully.";
    }

    // Login user
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    // Return login status
    public String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

        
    

